#!/usr/bin/env python3
"""
virtual_pepper_controller.py

Node ROS (Noetic / Python3) to control a virtual Pepper in Gazebo:
- publishes /cmd_vel (geometry_msgs/Twist)
- listens to simple "event" topics under /remote/
- captures images from camera topics (synchronous using wait_for_message)
- optional wikipedia query via /remote/get_knowledge (std_msgs/String) and publishes result on /remote/knowledge_result
"""

import rospy
from std_msgs.msg import String, Float32
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from std_srvs.srv import Empty, EmptyResponse
import os
import time
import wikipedia
import threading
import cv2
import numpy as np

class VirtualPepperController:
    def __init__(self):
        rospy.init_node('virtual_pepper_controller', anonymous=False)

        # Parameters
        self.max_lin_vel = rospy.get_param('~max_lin_vel', 0.35)
        self.max_ang_vel = rospy.get_param('~max_ang_vel', 1.0)
        self.front_cam_topic = rospy.get_param('~front_cam_topic', '/pepper_robot/camera/front/image_raw')
        self.bottom_cam_topic = rospy.get_param('~bottom_cam_topic', '/pepper_robot/camera/bottom/image_raw')
        self.depth_cam_topic = rospy.get_param('~depth_cam_topic', '/pepper_robot/camera/depth/image_raw')  # if available
        self.image_folder = rospy.get_param('~image_folder', os.path.join(os.path.expanduser('~'), 'pepper_images'))

        if not os.path.exists(self.image_folder):
            os.makedirs(self.image_folder)

        # Publisher to move the robot
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

        # Subscribers (events)
        rospy.Subscriber('/remote/capture_image', String, self.cb_capture_image)
        rospy.Subscriber('/remote/move_forward', Float32, self.cb_move_forward)
        rospy.Subscriber('/remote/turn_right', Float32, self.cb_turn_right)
        rospy.Subscriber('/remote/turn_left', Float32, self.cb_turn_left)
        rospy.Subscriber('/remote/turn_around', Float32, self.cb_turn_around)
        rospy.Subscriber('/remote/stop', Empty, self.cb_stop)
        rospy.Subscriber('/remote/get_knowledge', String, self.cb_get_knowledge)

        # Publisher for knowledge results (optional)
        self.knowledge_pub = rospy.Publisher('/remote/knowledge_result', String, queue_size=1)

        self.bridge = CvBridge()
        rospy.loginfo("VirtualPepperController initialized")

    # Image capture routine (blocking: waits a message from camera topic then saves)
    def capture_and_save(self, topic, prefix='img'):
        try:
            rospy.loginfo("Waiting for image on topic: %s", topic)
            img_msg = rospy.wait_for_message(topic, Image, timeout=5.0)
        except rospy.ROSException:
            rospy.logwarn("No image received on %s (timeout).", topic)
            return False, ""

        try:
            cv_image = self.bridge.imgmsg_to_cv2(img_msg, desired_encoding='bgr8')
        except CvBridgeError as e:
            rospy.logerr("CvBridge error: %s", str(e))
            return False, ""

        # Build filename
        tstamp = time.strftime("%Y%m%d-%H%M%S")
        filename = os.path.join(self.image_folder, "{}-{}.png".format(prefix, tstamp))
        # Save with cv2
        cv2.imwrite(filename, cv_image)
        rospy.loginfo("Saved image: %s", filename)
        return True, filename

    # Callbacks for remote events
    def cb_capture_image(self, msg):
        mode = str(msg.data).lower()
        rospy.loginfo("capture_image event received: %s", mode)
        if mode == '2d' or mode == 'front':
            ok, fn = self.capture_and_save(self.front_cam_topic, prefix='front')
        elif mode == 'bottom':
            ok, fn = self.capture_and_save(self.bottom_cam_topic, prefix='bottom')
        elif mode == 'depth' or mode == '3d':
            ok, fn = self.capture_and_save(self.depth_cam_topic, prefix='depth')
        else:
            rospy.logwarn("Unknown capture mode: %s", mode)
            return
        if ok:
            rospy.loginfo("Image captured and saved: %s", fn)

    def publish_twist(self, linear_x=0.0, angular_z=0.0, duration=0.0):
        """Publish Twist for duration seconds (non-blocking if duration==0)"""
        t = Twist()
        t.linear.x = linear_x
        t.angular.z = angular_z
        rate = rospy.Rate(10)
        if duration <= 0.0:
            self.cmd_vel_pub.publish(t)
            return
        end_time = rospy.Time.now() + rospy.Duration(duration)
        rospy.loginfo("Publishing Twist for %.2fs: lin=%.2f ang=%.2f", duration, linear_x, angular_z)
        while rospy.Time.now() < end_time and not rospy.is_shutdown():
            self.cmd_vel_pub.publish(t)
            rate.sleep()
        # stop
        self.cmd_vel_pub.publish(Twist())

    def cb_move_forward(self, msg):
        dur = float(msg.data)
        linear = self.max_lin_vel
        # run in thread so callback returns quickly
        threading.Thread(target=self.publish_twist, args=(linear, 0.0, dur)).start()

    def cb_turn_right(self, msg):
        dur = float(msg.data)
        ang = -abs(self.max_ang_vel)
        threading.Thread(target=self.publish_twist, args=(0.0, ang, dur)).start()

    def cb_turn_left(self, msg):
        dur = float(msg.data)
        ang = abs(self.max_ang_vel)
        threading.Thread(target=self.publish_twist, args=(0.0, ang, dur)).start()

    def cb_turn_around(self, msg):
        dur = float(msg.data)
        ang = abs(self.max_ang_vel)  # rotate left for duration
        threading.Thread(target=self.publish_twist, args=(0.0, ang, dur)).start()

    def cb_stop(self, req):
        rospy.loginfo("Stop event received")
        self.cmd_vel_pub.publish(Twist())
        return EmptyResponse()

    def cb_get_knowledge(self, msg):
        query = str(msg.data).strip()
        rospy.loginfo("Knowledge request: %s", query)
        try:
            summary = wikipedia.summary(query, sentences=2)
        except Exception as e:
            summary = "Error fetching Wikipedia: {}".format(e)
        self.knowledge_pub.publish(summary)

    def spin(self):
        rospy.spin()

if __name__ == '__main__':
    node = VirtualPepperController()
    try:
        node.spin()
    except rospy.ROSInterruptException:
        pass

